import Phaser, { Input, Scene } from 'phaser';
import { Dialog, DialogUpdateAction } from '../objects/Dialog';
import { DEFAULT_DIALOG_LINE_CREATE_OPTS } from '../objects/DialogLine';
import { WINDOW_WIDTH, WINDOW_HEIGHT } from '../constants';
import { Player } from '../entities/Player';
import { IEntity } from '../entities/Entity';
import BaseScene from './BaseScene';

const chant = [
	'JINZOU FIRE FAIBO WAIPAA', 
	'TAIGA TAIGA TTTTAIGA', 
	'CHAPE APE KARA KINA' ,
	'CHAPE APE KARA KINA' ,
	'MYOHHONTUSUKE' ,
	'*CLAP* WAIPAA!!', 
	'FIRE FIRE' ,
	'TORA TORA KARA KINA',
	'CHAPE APE BABA',
	'AMA AMA JYASUPA!',
	'TORA TAIGA, DARE TAIGA!',
	'JINZOU SENI YA TAIGA!'
];

export default class Demo extends BaseScene {
	dialog?: IDialog;
	player?: Player;

	constructor() {
		super('GameScene');
	}

	preload() {
		super.preload();

		Dialog.preload(this);
		Player.preload(this);
	}

	create() {
		super.create();

		this.dialog = this.add.dialog({
			...DEFAULT_DIALOG_LINE_CREATE_OPTS,
			text: chant,
		});
		this.input.on('pointerdown', () => {
			this.dialog?.update(this, { dialogUpdate: DialogUpdateAction.PROGRESS });
		});

		this.player = new Player(this, { x: WINDOW_WIDTH/2, y: WINDOW_HEIGHT/2, texture:'enna' });
	}

	update() {
		super.update();

		this.dialog?.update(this, {});
		this.player?.update(this);
	}
}
