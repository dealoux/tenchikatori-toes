export const WINDOW_WIDTH = 1920;
export const WINDOW_HEIGHT = 1080;